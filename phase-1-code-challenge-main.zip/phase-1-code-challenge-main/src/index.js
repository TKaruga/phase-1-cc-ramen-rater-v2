// Initialize url to 'http://localhost:5500'
const API_URL = 'http://localhost:3000';

// When the DOM content is loaded:
//     a. Fetch and display the details of the first movie using fetchMovieDetails(1)
//     b. Fetch and display the list of movies using fetchMoviesList()
//     c. Add a click event listener to the 'Buy Ticket' button to execute buyTicket()

document.addEventListener('DOMContentLoaded', () => {
    fetchMovieDetails(1)
        .catch(error => {
            console.error('Error fetching movie details:', error);
        });


    fetchMoviesList()
        .catch(error => {
            console.error('Error fetching movies list:', error);
        });

    document.getElementById('buy-ticket').addEventListener('click', buyTicket);
});

async function fetchMovieDetails(id) {
    try {
        const response = await fetch(`${API_URL}/films/${id}`);
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const movie = await response.json();
        displayMovieDetails(movie);
    } catch (error) {
        console.error('Fetch movie details error:', error);
        throw error;
    }
}

async function fetchMoviesList() {
    try {
        const response = await fetch(`${API_URL}/films`);
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const movies = await response.json();
        displayMoviesList(movies);
    } catch (error) {
        console.error('Fetch movies list error:', error);
        throw error;
    }
}

function displayMovieDetails(movie) {
    const { poster, title, runtime, showtime, tickets_sold, capacity, description } = movie;
    const availableTickets = capacity - tickets_sold;

    document.getElementById('poster').src = poster;
    document.getElementById('title').textContent = title;
    document.getElementById('runtime').textContent = `${runtime} minutes`;
    document.getElementById('showtime').textContent = showtime;
    document.getElementById('film-info').textContent = description;
    document.getElementById('ticket-num').textContent = `${availableTickets}`;

    updateBuyButton(availableTickets);
}

function displayMoviesList(movies) {
    const filmsList = document.getElementById('films');
    filmsList.innerHTML = ''; // Clear previous list

    movies.forEach(movie => {
        const listItem = createFilmListItem(movie);
        filmsList.appendChild(listItem);
    });
}

function createFilmListItem(movie) {
    const listItem = document.createElement('li');
    listItem.textContent = movie.title;
    listItem.classList.add('film', 'item');

    // Delete button
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.classList.add('ui', 'red', 'button', 'right', 'floated');

    deleteButton.addEventListener('click', (event) => {
        event.stopPropagation(); // Prevent list item click event

        deleteFilm(movie.id)
            .then(() => {
                listItem.remove();
            })
            .catch(error => {
                console.error('Error deleting film:', error);
            });
    });

    listItem.appendChild(deleteButton);

    listItem.addEventListener('click', () => {
        fetchMovieDetails(movie.id)
            .catch(error => {
                console.error('Error fetching movie details:', error);
            });
    });

    return listItem;
}

function buyTicket() {
    const availableTickets = parseInt(document.getElementById('ticket-num').textContent);

    if (availableTickets > 0) {
        const updatedTickets = availableTickets - 1;
        document.getElementById('ticket-num').textContent = `${updatedTickets}`;

        updateTicketsSold(updatedTickets);
        updateBuyButton(updatedTickets);
    } else {
        alert('Sold Out, no tickets available');
    }
}

async function updateTicketsSold(updatedTickets, movieId) {
    // Validate inputs
    if (typeof updatedTickets !== 'number' || updatedTickets < 0) {
        throw new Error('Invalid number of tickets');
    }

    if (!movieId || typeof movieId !== 'string') {
        throw new Error('Invalid movie ID');
    }

    const data = {
        tickets_sold: updatedTickets
    };

    const url = `${API_URL}/films/${movieId}`;

    try {
        const response = await fetch(url, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        // Check if response is not okay
        if (!response.ok) {
            let errorMessage = `Error updating tickets for movie ID ${movieId}: ${response.status} - ${response.statusText}`;

            // parse response body for additional error details
            try {
                const responseBody = await response.json();
                if (responseBody && responseBody.error) {
                    errorMessage += ` - ${responseBody.error}`;
                }
            } catch (parseError) {
                console.warn('Error parsing response body:', parseError);
            }

            throw new Error(errorMessage);
        }

        // Return the updated data needed
        const updatedData = await response.json();
        return updatedData;

    } catch (error) {
        console.error('Update tickets sold error:', error);
        throw error;
    }
}


async function deleteFilm(id) {
    try {
        const response = await fetch(`${API_URL}/films/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
    } catch (error) {
        console.error('Delete film error:', error);
        throw error;
    }
}

function updateBuyButton(availableTickets) {
    const buyButton = document.getElementById('buy-ticket');
    
    if (availableTickets === 0) {
        buyButton.textContent = 'Sold Out';
        buyButton.classList.add('disabled');
    } else {
        buyButton.textContent = 'Buy Ticket';
        buyButton.classList.remove('disabled');
    }
}
